File with subextension .jsz.js is created by HTMLZip/JSZip tool. It's compressor, packer, minifier.
See about tool and more compressed scripts at http://www.htmlzip.com.